# FIT3179 / FIT2179 DV2 — WEEK 11 CRITIQUE PREPARATION

## This is NOT the Week 12 interview

The **Week 11 Data Visualisation 2 Critique** is a separate, group-of-two assessment worth **4% of the overall unit mark** (source: uploaded `FIT2179 DV2 Critique Requirements.pdf`, pages 1–2). It requires:

1. **Before studio:** make a public draft of your DV2 website on GitHub and post the URL on the Moodle group forum. The draft must have several meaningful diagrams and show layout, typography and colour design. The handout warns of a **penalty of up to 2%** for a very small number of basic charts.
2. **In studio:** tutor pairs you with another student. Review their public website for **10 minutes** using the main DV2 rubric.
3. **On their Moodle post:** write **at least four constructive bullet points**, ordered from highest to lowest priority. Be specific about problems and proposed fixes.
4. **To the studio group:** present a **two-minute critique** of your peer's visualisation.
5. **Discussion:** allow **three minutes** of feedback/discussion from tutor and students.

**Marking:** Presentation (2%; well-structured, clear, on time; **0% for presentation if over time**), and critique/suggestions (2%; **4 valid substantial points × 0.5%**). The tutor may deduct **0.5% for each major missed flaw**, e.g. treating absolute numbers as rates, using hue on a quantitative variable, or making a misleading display.

### Personal preparation script (about 35 seconds)

“My draft explores organ donation in Australia. My story begins with new registrations from 2020 to 2025, compares states using both registration rates and actual donor counts, then explores age patterns and family consent. The data comes from DonateLife and Services Australia. I selected a choropleth, proportional-symbol map and schematic tile-grid map because they answer distinct geographic questions. The most important design concern I'm still testing is whether those three are accepted as different map idioms.”

### How to critique your partner: a timed plan

- **0–10s:** Name the visualisation and acknowledge its main intended message.
- **10–35s:** Point 1: identify the **most important** data accuracy / rate / misleading comparison issue (only if present); describe an exact fix.
- **35–60s:** Point 2: assess idiom suitability, e.g. an ineffective map, inappropriate colour scale or missing context; propose a clear improvement.
- **60–85s:** Point 3: assess narrative structure, chart annotations, intended audience and completeness; show where it breaks.
- **85–110s:** Point 4: assess interactions, layout, typography or legibility; explain specifically how to improve it.
- **110–120s:** Conclude with one priority action.

Never fabricate criticisms; only comment on what you can genuinely observe. The following are prompts, not pre-written criticism to submit:

- “In chart __, the comparison uses total counts for regions of very different population sizes. I'd recommend showing the value per 100,000 people or an eligible-population rate instead, and clearly stating the denominator.”
- “In chart __, colour hue suggests ordered magnitude but does not show a clear lightness sequence. A sequential lightness palette plus an explicit legend would make quantitative comparisons more reliable.”
- “The transition between sections __ and __ is unclear. A one-sentence takeaway and a highlighted data point could connect them to the overall research question.”
- “At laptop width, chart __ is hard to read or requires horizontal scrolling. I suggest reducing clutter, shorter labels and a responsive stacked layout.”

### Questions for your tutor about YOUR project

1. Does Australia satisfy the assigned topic and audience requirement for **my Malaysia-campus enrolment**, or must I obtain approval/adapt the audience?
2. Will the **choropleth map**, **proportional symbol map** and **schematic tile-grid map** count as three different *map idioms*?
3. Are the registration-only and donation pathway graphs too concentrated on a few datasets, or is the combined source coverage adequate?
4. Which idioms should I replace or strengthen for the **8 advanced idioms** target?
5. Are any chart labels, source caveats, colour choices or story transitions confusing to an average reader?

### Quick pre-critique upload checklist

[ ] GitHub Pages URL works in a private/incognito tab.
[ ] All charts appear; no JS errors or “loading chart” messages are stuck.
[ ] Three different mapped views are visible and correct.
[ ] Public repository has human-readable `charts/*.json`.
[ ] Sources and limitations are visible in the website footer.
[ ] You have posted the live URL to Moodle.
[ ] You have a timer ready for your peer's two-minute critique.
