#!/usr/bin/env python3
from pathlib import Path
import csv,json,sys
p=Path(__file__).resolve().parent.parent
names=sorted((p/'charts').glob('*.json'))
assert len(names)==13, len(names)
for c in names:
 spec=json.loads(c.read_text(encoding='utf8'))
 assert spec['$schema'].endswith('v5.json'), c
 s=str(spec)
 import re
 for name in re.findall(r'data/[A-Za-z0-9_]+\.csv',s):
  assert (p/name).exists(),(c,name)
assert sum(int(x['new_registrations']) for x in csv.DictReader(open(p/'data'/'new_registrations_2020_2025.csv')) if x['year']=='2025')==147969
state=list(csv.DictReader(open(p/'data'/'state_2025.csv')))
assert sum(int(x['deceased_donors']) for x in state)==557
assert sum(int(x['transplant_recipients']) for x in state)==1438
assert len(list(csv.DictReader(open(p/'data'/'registration_waffle_2025.csv'))))==100
print('PASS: 13 valid JSON files, all referenced CSV files exist, core numerical assertions hold.')
print('Note: No actual browser test has been run by this script.')
