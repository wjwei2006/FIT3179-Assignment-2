# DRAFT MOODLE SUBMISSION EXPLANATION — EDIT BEFORE SUBMITTING

**Live visualisation URL:** [INSERT YOUR REAL PUBLIC GITHUB PAGES URL]

**Hand-drawn sketch PDF URL:** [INSERT YOUR SCANNED/HAND-DRAWN SKETCH PDF LINK IN THE GITHUB REPO]

**Project title:** The Gift of Life: Organ Donation in Australia

**Domain / Who / Why:**
This data story explores organ donation and transplantation in Australia for readers with no specialist medical or data-analysis background. It aims to help readers understand the important difference between registering as a potential organ donor, receiving family agreement, meeting the medical criteria for deceased donation and actually becoming an organ donor. Through a sequence of charts and maps, the visualisation makes changes in registration participation, state-level variation and the role of consent easier to see and interpret. **[TUTOR APPROVAL NEEDED: Explain how Australia is relevant to the required audience if enrolled at the Malaysia campus.]**

**What / Data:**
Data were taken from DonateLife / Organ and Tissue Authority's 2025 registration, donation and transplantation data and from Services Australia's Australian Organ Donor Register statistics as at 31 August 2026. The registration source provides annual new registrations for 2020–2025 and state-level registration rates among residents aged 16+ in 2025. The donation source provides the number of deceased donors, transplant recipients and family consent rates. Services Australia provides a separate breakdown of published legally valid consent records by sex, age and state; its documentation notes that these tables include some objection records. This distinction is made explicit and the 2026 statistics are not directly combined with 2025 counts. The 2025 source data were transcribed into CSV format and selected new ranks, proportions and chart-layout values calculated for use in Vega-Lite. Data and sources are linked in the website's credits.

**How / Rationale:**
The visualisation is arranged as a vertical storytelling webpage. First, a line chart shows national change over time; a heatmap and bump chart provide state-level context. Three proposed geographic views present state registration coverage (choropleth), deceased donor counts (proportional-symbol map), and family consent rates (schematic tile grid). This combination separates rate, magnitude and schematic comparison. A dumbbell chart communicates 2024–2025 change, while a treemap shows how each state contributes to the national count. A population pyramid and normalised heatmap compare age and sex records in the August 2026 AODR tables. An annotated comparative consent graphic and donor pathway show the importance and limitations of hospital eligibility and family decisions. Hover tooltips and a highlightable legend support focused reading without obscuring the main story. The design uses consistent spacing, restrained colours, contrasting serif/sans typography, explanatory annotations and clearly labelled sources and caveats.

**AI-use acknowledgement:**
I used generative AI to assist with brainstorming, story structure, draft written content, dataset transcription/checking, HTML/CSS/JavaScript construction and Vega-Lite specifications. I reviewed and edited the visualisations, checked their data against their sources, and took responsibility for the final design and submission. **[ONLY CLAIM THE REVIEW/EDITING YOU ACTUALLY PERFORMED.]**

**Authorship:**
[INSERT YOUR OWN NAME], October 2026.

**Important:** This file is a *draft*. Do not submit it before confirming tutor approval for topic/audience, checking idiom validity, replacing links, personally reviewing charts, and producing the hand-drawn sketch.
