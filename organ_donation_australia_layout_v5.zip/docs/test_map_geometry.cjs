// Run from project root: node docs/test_map_geometry.cjs
const assert=require('node:assert/strict');
const G=require('../map_geometry.js');
const makeState=(name,i)=>{
 const x=111+i*5;
 // CCW exterior (RFC 7946), contains duplicates, nonclosed islands,
 // a 2-point degenerate island and an invalid 2-point hole.
 return {type:'Feature',properties:{STATE_NAME:name},geometry:{type:'MultiPolygon',coordinates:[
   [ [[x,-30],[x+2,-30],[x+2,-28],[x+2,-28],[x,-28],[x,-30]], [[x+.5,-29.5],[x+.5,-29.3]] ],
   [ [[x+2.1,-30],[x+2.2,-30]] ],
   [ [[x+2.5,-30],[x+2.8,-30],[x+2.8,-29.7],[x+2.5,-29.7]] ]
 ]}};
};
const source={type:'FeatureCollection',features:G.EXPECTED_STATES.map(makeState)};
const result=G.normalizeFeatures(source);
assert.equal(result.length,8);
for(const f of result){
 assert.equal(f.geometry.type,'MultiPolygon');
 assert.equal(f.geometry.coordinates.length,2, 'keep valid mainland and island; discard invalid shell');
 for(const polygon of f.geometry.coordinates){
   assert.equal(polygon.length,1,'skip malformed hole');
   const ring=polygon[0];
   assert.deepEqual(ring[0],ring.at(-1),'ring is closed');
   assert.ok(G.signedArea(ring)<0,'shell has D3-compatible clockwise winding');
 }
}
assert.throws(()=>G.normalizeFeatures({type:'FeatureCollection',features:source.features.slice(1)}),/Missing Australian state boundaries/);
const hole=G.cleanRing([[120,-30],[120,-29],[121,-29],[121,-30]],false);
assert.ok(hole && G.signedArea(hole)>0,'hole is anticlockwise');
assert.equal(G.cleanRing([[120,-30],[121,-30]],true),null);
assert.equal(G.cleanRing([[120,-30],[120,-30],[120,-30],[120,-30]],true),null);
assert.equal(G.cleanRing([[999,-30],[121,-30],[121,-29]],true),null);
console.log('PASS: 8-state coverage; malformed rings ignored; holes; winding; closure; missing states check.');
