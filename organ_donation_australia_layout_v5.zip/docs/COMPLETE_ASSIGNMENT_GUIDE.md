# COMPLETE ASSIGNMENT GUIDE — THE GIFT OF LIFE: AUSTRALIA

## 1. Assignment aim and proposed interpretation

**Domain:** Public health / organ donation and transplantation in Australia.

**Official topic (from your tutor):** “Explore organ donation registrations and transplant statistics in Australia. Compare changes over time and investigate public participation. Identify trends that may influence donation rates.”

**Proposed webpage title:** “The Gift of Life: Organ Donation in Australia.”

**Core question:** How does organ-donor participation vary across time and states, and how do registration and family consent relate to actual deceased organ donation?

**Who:** General public who may be unfamiliar with donor registration. **Course caveat:** Since the student is Malaysia-campus, Australia does not automatically satisfy the Malaysia-audience requirement without tutor confirmation.

**Why:** Replace several disconnected administrative statistics with a clear, cautious story that distinguishes annual registrations, population coverage, family consent, clinical eligibility, deceased donors and recipients.

**What:** Quantitative records of donor registration and donation, geographic state/territory categories, dates 2020–2025 and legally valid AODR registrations by age/sex published August 2026.

**How:** A long-form, single-page narrative website composed of authored Vega-Lite graphics, typographic hierarchy, deliberately selected idioms, interactive tooltips, linked legend filtering (bump chart), explanatory notes and visible source citations.

## 2. Exact rubric and critical restrictions

Final DV2 is worth 25% of final unit mark and due **25 October 2026 at 11:55 PM**. The Week 11 group-of-two critique is a separate 4%. The final visualisation must be served from a **public, single-page GitHub Pages URL** and have readable Vega-Lite chart JSON in the repo. More than ten distinct meaningful charts and **at least three different map idioms** are required for the high-grade idiom criterion. The rubric's HD threshold is eight advanced idioms across >10 charts. All maps count as advanced, but three map idioms may not be unambiguously met by a choropleth, proportion-symbol and tile-grid: **confirm with tutor**. Include at least two reliable data sources. The site must be usable at laptop width without horizontal scrolling and load with a small data footprint. Charts should tell a story, not simply reproduce a dashboard. The submitted A4 sketch must have been **hand-drawn**; photograph/scan it to PDF yourself. Maintain authorship, cite sources and acknowledge AI use.

## 3. Storyboard and how to draw the sketch (by hand)

On a **single A4 sheet**, use pencil and ruler. Do not digitally generate a sketch; the rubric gives **0 if created with digital tools**. Split the paper into six clearly labelled blocks in this order:

**Block A / Header:** 'The Gift of Life', short subtitle, a wide hero area with national 35%, 557, 1,438 and 53% as numeric callouts. Sketch the single scrolling page from top to bottom.

**Block B / Registration trend:** draw a line with 2021 peak annotation, a state-vs-year heatmap grid, and a compact bump chart. Add a short explanatory sentence under each.

**Block C / Geography:** draw three **visually different** sketches: choropleth states shaded by percent registered, large/small circles sized by deceased donors, and a schematic state tile grid shaded by consent %. Label units, legends and hover details.

**Block D / Change and demographics:** draw a two-ended dumbbell 2024-vs-2025, 2-column area treemap for 2025 state sign-ups, and the female-vs-male age pyramid and state age composition heatmap.

**Block E / Family consent:** draw reference bars for 82%, 63%, 38%, and a progressively narrowing donor pathway graphic showing approximate 1,670 → 1,500 → 790 → 557.

**Block F / Takeaway and footer:** 100-cell waffle 35 coloured cells; text caveat explaining why registered != actual donor; source list, own author name/date and AI acknowledgement.

Use arrows to show scroll direction, approximate relative card sizes, and labels for key colours and interactions. The final site should follow this sketch; if your earlier official sketch was on another topic, discuss the rubric penalty with your tutor.

## 4. Chart-by-chart plan, marks, channels and purpose

Each chart below has its own JSON file and a local CSV dataset. Marks/channels are described in the same What/Why/How vocabulary taught in the unit.

### 01. 01 · Registration trends

- **Idiom:** Line + annotated area.
- **Main takeaway:** New registrations surged in 2021, then declined through 2025.
- **Marks and channels:** Year on x; annual registration count on y.
- **Data and processing:** 2020–2025 new registrations; summing states equals each official total.
- **Caution:** 2021 peak is a pattern, not an explanation.
- **Source code:** `charts/01_registrations_trend.json`.

### 02. 02 · Which states drove the changes?

- **Idiom:** Heatmap.
- **Main takeaway:** The concentration of new registrations has changed unevenly across states.
- **Marks and channels:** State rows × year columns; sequential colour encodes count.
- **Data and processing:** New registrations from DonateLife.
- **Caution:** Counts reflect state population; not rates.
- **Source code:** `charts/02_state_year_heatmap.json`.

### 03. 03 · The changing state rankings

- **Idiom:** Bump chart.
- **Main takeaway:** Rank can reveal a different story from raw counts.
- **Marks and channels:** Position on y encodes annual rank; connecting lines encode shifts.
- **Data and processing:** Ranks recalculated from DonateLife annual registrations.
- **Caution:** Ranking hides differences in magnitude; hover for counts.
- **Source code:** `charts/03_state_rank_bump.json`.

### 04. 04 · Registration is not evenly distributed

- **Idiom:** Choropleth map.
- **Main takeaway:** A share of the eligible population gives a fairer state comparison than total sign-ups.
- **Marks and channels:** State shape; colour lightness encodes % of people age 16+ registered.
- **Data and processing:** DonateLife 2025 registration rates.
- **Caution:** State coverage, not annual sign-ups; geography from an external GeoJSON.
- **Source code:** `charts/04_choropleth_reg_rate.json`.

### 05. 05 · Where did deceased donors come from?

- **Idiom:** Proportional symbol map.
- **Main takeaway:** Circle area shows where deceased organ donations occurred in 2025.
- **Marks and channels:** Geographic position for states; area proportional to deceased donors.
- **Data and processing:** DonateLife 2025 deceased donor counts.
- **Caution:** Circles are positioned for legibility, not precise hospital locations.
- **Source code:** `charts/05_symbol_map_donors.json`.

### 06. 06 · The family consent picture

- **Idiom:** Tile grid map.
- **Main takeaway:** A schematic tile grid gives each state equal visibility, including small ACT and Tasmania.
- **Marks and channels:** Each state one equal-size tile; lightness encodes consent percentage.
- **Data and processing:** DonateLife state/territory consent rates, 2025.
- **Caution:** Tiles are schematic, not physical geographic areas.
- **Source code:** `charts/06_tile_grid_consent.json`.

### 07. 07 · What changed in the latest year?

- **Idiom:** Dumbbell chart.
- **Main takeaway:** Most states recorded fewer new registrations in 2025 than in 2024.
- **Marks and channels:** Two endpoints per state encode 2024 and 2025.
- **Data and processing:** DonateLife 2024/2025 new registrations.
- **Caution:** Not a rate; state population sizes vary.
- **Source code:** `charts/07_state_change_dumbbell.json`.

### 08. 08 · Age and recorded sex

- **Idiom:** Population pyramid.
- **Main takeaway:** The two sides show age patterns in AODR legally valid consent records, not a population rate.
- **Marks and channels:** Mirrored horizontal positions represent female and male record counts.
- **Data and processing:** Services Australia August 2026 age-sex table.
- **Caution:** Published table includes objection records; 2026 data, not 2025.
- **Source code:** `charts/08_age_sex_pyramid.json`.

### 09. 09 · A different age mix in each state

- **Idiom:** Normalised heatmap.
- **Main takeaway:** Within-state percentages help compare age composition without state size dominating.
- **Marks and channels:** Row = state; column = age; lightness = share of that state’s records.
- **Data and processing:** Services Australia August 2026 table summed across published female/male records.
- **Caution:** Not adjusted for age composition of the entire state population.
- **Source code:** `charts/09_age_mix_state_heatmap.json`.

### 10. 10 · Knowing a person’s wishes matters

- **Idiom:** Reference bar chart.
- **Main takeaway:** Family agreement differs substantially by what is known about a person’s wishes.
- **Marks and channels:** Horizontal position/length of bar encodes percent consenting.
- **Data and processing:** DonateLife 2025 family-agreement context figures.
- **Caution:** Overlapping categories; observational associations, not causal effects.
- **Source code:** `charts/10_family_agreement.json`.

### 11. 11 · From possibility to donation

- **Idiom:** Funnel chart.
- **Main takeaway:** Only a small set of deaths make organ donation medically possible.
- **Marks and channels:** Symmetric bar width encodes counts along donation pathway.
- **Data and processing:** DonateLife 2025 national fact sheet.
- **Caution:** Potential donors and families approached are approximate; recipients are not a downstream donor conversion rate.
- **Source code:** `charts/11_donation_pathway.json`.

### 12. 12 · The national total is made of states

- **Idiom:** Treemap.
- **Main takeaway:** Each area represents a state’s share of 2025 new AODR registrations.
- **Marks and channels:** Rectangle area (and labels) encodes the share of new registrations.
- **Data and processing:** DonateLife 2025 state registrations, proportional slice-and-dice treemap.
- **Caution:** Total counts, not registration rates.
- **Source code:** `charts/12_treemap_registrations.json`.

### 13. 13 · What does 35% look like?

- **Idiom:** Waffle chart.
- **Main takeaway:** Roughly one out of three eligible Australians was registered in 2025.
- **Marks and channels:** 35 coloured cells of 100 encode 35%.
- **Data and processing:** DonateLife 2025 registration rate among age 16+.
- **Caution:** Illustrative 100-cell representation of an aggregate percentage.
- **Source code:** `charts/13_waffle_coverage.json`.

## 5. Which data are used for which chart?

- **DonateLife registration source:** 01, 02, 03, 04, 07, 12, 13. It has rows for 2020–2025 new registrations, and 2025 percentage of the eligible age-16+ population registered.
- **DonateLife donation state overview:** 05, 06, and the 2025 national headline numbers, with 2025 actual deceased donors, transplant recipients and family consent rates by state.
- **DonateLife factsheet and registration page:** 10 and 11, with 82/63/38% family agreement contexts and pathway 1,670 potential donors; 1,500 families approached; 790 agreed; 557 donated.
- **Services Australia August 2026:** 08 and 09, age/sex state tables of legally valid consent registrations (including objection records). Both charts warn of the data caveat.

**Data cleaning:** CSVs are manually transcribed and checked against source row sums. `state_rankings.csv`, `state_changes_2024_2025.csv`, `age_share_within_state_aug_2026.csv`, `state_registration_treemap_2025.csv` and `registration_waffle_2025.csv` are mathematically derived from those source figures. No raw values are fabricated; some display coordinates are illustrative positioning data (see next point).

**Geospatial caveat:** The approximate map circle coordinates are for visually positioning state-count circles, *not* locations of medical facilities, donors or recipients. The schematic tile layout is a deliberate cartographic abstraction.

**Values you should be able to explain:** 35% eligible population registered 2025; 147,969 new registrations in 2025; 557 deceased donors; 1,438 recipients; 53% national family consent; 2021 saw 349,947 new registrations. In SA, 74% eligible were registered versus 15% in NT. These are different measures. Official donor pathway approximate ~1,670/1,500/790/557.

## 6. Colour, typography, layout and audience

- **Background:** warm off-white `#f7f9f7` to minimise visual fatigue.
- **Header:** deep blue-green `#0f3440` to communicate seriousness and clarity.
- **Main sequential visual channel:** teal lightness / sequential scheme for ordered percentages or counts; avoid unordered hues for quantitative magnitude.
- **Accent:** pale orange `#E6A86C` for symbol attention, not a second competing numeric scale.
- **Text:** dark navy and medium grey for contrast; narrative serif display headers (`DM Serif Display`), utilitarian body sans (`DM Sans`).
- **Layout:** consistent gutters, a two-column chart grid on larger screens that collapses to one column on smaller screens. Each chart card includes annotation and a limitation.
- **Reading order:** trend → geography → comparison → demographics → family consent → conclusion. Avoid assuming readers understand epidemiological or statistical jargon.

## 7. Interactivity and accessibility

- Hover Vega-Lite chart marks for tooltips including explicit units.
- Bump chart allows selection from legend to highlight a state.
- Source links provided next to methods and in footer. Each section has an anchored location within the **same page**, not a route switch.
- Responsive chart container sizing and reduced body width; check a real 1366 × 768 or smaller screen before claiming complete.
- Don’t add gratuitous interaction that hides an essential conclusion.

## 8. Testing you should do in your browser

Use a **local HTTP server**, never open the HTML by `file://`. Test each of the 13 charts, then inspect developer console. Specifically ensure: choropleth has eight state shapes with correct tooltips, proportional symbol area variation is visible, schematic tile grid has 8 correctly labelled tiles, and the pyramid and funnel have accurate numerical values. Test missing internet or third-party map file errors. Compare 2025 state totals to DonateLife, and inspect 2026 age/sex subtotals against Services Australia. Validate high colour contrast, laptop width and legibility.

## 9. Outstanding tasks before final submission

1. Confirm the assignment permits an Australia-focused topic and Australian-audience style at Malaysia campus.
2. Confirm the tile grid genuinely qualifies as a third map idiom; if not, replace with tutor-approved option.
3. Test and if necessary replace externally loaded GeoJSON with licensed official ABS state boundaries.
4. Check idiom count **and effectiveness**, not just count file names.
5. Hand-draw and scan your A4 sketch. Keep your final webpage close to it.
6. Verify the actual website in a private browser tab and publish to a public GitHub repo.
7. Replace author-name placeholder, audit AI use, and write the actual submitted explanation based on charts you understand.

## 10. Sources and independent sources

DonateLife / Organ and Tissue Authority: <https://www.donatelife.gov.au/all-about-donation/donation-and-transplantation-data?section=registration-data> and <https://www.donatelife.gov.au/all-about-donation/donation-and-transplantation-data?section=overview> and <https://www.donatelife.gov.au/sites/default/files/2026-03/2025%20donation%20and%20transplantation%20data%20summary%20factsheet%20-%20FINAL%20accessible%20PDF.pdf>.

Services Australia: <https://www.servicesaustralia.gov.au/australian-organ-donor-register-statistics?context=22>.

Third-party map geometry: <https://github.com/rowanhogan/australian-states> (licence not verified).

Course documents: `FIT3179 Data Visualisation 2_v1.2.pdf` and `FIT2179 DV2 Critique Requirements.pdf` uploaded by the student; Weeks 7–10 studio materials uploaded by the student.
